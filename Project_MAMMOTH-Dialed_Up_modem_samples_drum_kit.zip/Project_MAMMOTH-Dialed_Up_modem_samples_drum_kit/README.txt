# Project MAMMOTH Dialed Up modem samples

These files are the modem samples that were recorded by Project MAMMOTH and
used as part of the Dialed Up track:
https://www.youtube.com/watch?v=euMZYqDG4Sc. The original .wav files are in the
"Dialup Sounds", and there is also a Drum Kit with these samples for use within
Ableton here: "Project Mammoth - Modem Kit.als"

See projectmammoth.com for more details on Project MAMMOTH.

Enjoy!
